:mod:`certbot.plugins.manual`
---------------------------------

.. automodule:: certbot.plugins.manual
   :members:
